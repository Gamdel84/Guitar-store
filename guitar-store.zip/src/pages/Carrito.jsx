import React from 'react';

export default function CarritoCompras({ carrito, setCarrito }) {
  const vaciarCarrito = () => {
    setCarrito([]);
  };

  const quitarCantidad = (idg) => {
    const carritoActualizado = carrito.map(g => {
      if (g.id === idg) {
        const cantidadActual = g.cantidad || 1;
        if (cantidadActual === 1) {
          return null;
        }
        return { ...g, cantidad: cantidadActual - 1 };
      }
      return g;
    }).filter(g => g !== null);

    setCarrito(carritoActualizado);
  };

    const agregarCantidad = (idg) => {
    const nuevoCarrito = carrito.map(g => {
      if (g.id === idg) {
        return {...g, cantidad: (g.cantidad || 1) + 1};
      }
      return g;
    });
    setCarrito(nuevoCarrito);
  };

  const total = carrito.reduce((sum, item) => {
    const cantidad = item.cantidad || 1;
    return sum + (Number(item.precio) * cantidad);
  }, 0);

  return (
    <div>
      <hr />
      <h2>Carrito de Compras</h2>
      {carrito.length === 0 ? (
        <p>El carrito está vacío</p>
      ) : (
        <>
          {carrito.map((item) => (
            <div key={item.id}>
                {item.marca} - ${Number(item.precio).toFixed(3)}
                (Cantidad: {item.cantidad || 1})
                <button onClick={() => quitarCantidad(item.id)}>-</button>
                 <button onClick={() => agregarCantidad(item.id)}>+</button>
            </div>
          ))}

          <div>
            <hr />
            Total: ${Number(total).toFixed(3)}
          </div>
          <button onClick={vaciarCarrito}>
            Vaciar Carrito
          </button>
        </>
      )}
    </div>
  );
}
