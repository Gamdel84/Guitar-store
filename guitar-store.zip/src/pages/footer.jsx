function Footer() {
    return (
        <footer>
            <div className="cuerdas">
            <hr />
            <hr />
            <hr />
           
            </div>
            <p>© 2025 Mi Aplicación. Todos los derechos reservados.</p>
            <div className="cuerdas">
            <hr />
            <hr />
            <hr />
           
            </div>
        </footer>
    )
}
export default Footer
