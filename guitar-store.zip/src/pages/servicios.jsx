import React from 'react'
import { Link } from 'react-router-dom';

function Servicios() {
  return (
    <div>
        <>
        <div className='servicios'>
            <h2>Servicios</h2>
            <p>Ofrecemos una variedad de servicios para satisfacer tus necesidades. Dejanos tu instrumento en boxes y te lo devolveremos como nuevo.</p>
            <Link to= "/">Volver al inicio</Link>
        </div>
        
        </>
        
        
    </div>
  )
}

export default Servicios;