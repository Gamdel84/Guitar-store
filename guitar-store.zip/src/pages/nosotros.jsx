import React from 'react'
import { Link } from 'react-router-dom'

function Nosotros() {
  return (
    <>
        <h2>Nosotros</h2>

            <section id="contacto">
                <div class="sec-contacto">
                    <h2>Contacto</h2>
                    <div class="map-contact">
                        
                        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d690.3790974717607!2d-58.381318843977574!3d-34.603783745536106!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x95bccacf3fc81b05%3A0x6d2a52045fcefe3b!2sAv.%20Corrientes%201080-1048%2C%20C1009%20Cdad.%20Aut%C3%B3noma%20de%20Buenos%20Aires!5e0!3m2!1ses-419!2sar!4v1759635581673!5m2!1ses-419!2sar" width="600" height="450" style={{border:0}} allowFullscreen="" loading="lazy" referrerPolicy="no-referrer-when-downgrade"></iframe>

                        <div class="info">
                            <div><img src="./src/assets/ubicacion.png" alt="ubicacion"/><a href="https://maps.app.goo.gl/Vc2Rv5XQqYUtuLhh7" target="_blank">Asamblea 1212 - CABA</a></div>

                            <div><img src="./src/assets/telefonis.png" alt=""/><a href="tel:+49434943">4943-4943</a></div>

                            <div><img src="./src/assets/mail.png" alt=""/><a href="mailto:puraespuma@puraespuma.com">puraespuma@puraespuma.com</a></div>

                            <div><img src="./src/assets/instagrrram.png" alt=""/><a href="https://www.instagram.com" target="_blank">PuraEspuma</a></div>
                        </div>
                        
                    </div>

                    <form action="mailto:holaquetal@gmail.com" method="post">

                        <label> Nombre: 
                            <input type="text" name="Nombre" placeholder="Escribí tu nombre..."/>
                        </label>

                        <label> Telefono:
                            <input type="tel" name="Telefono" placeholder="Ej: 11-1234-5678" required/>
                        </label>

                        <label> E-mail:
                            <input type="email" name="Email" placeholder="Ej: nombre@ejemplo.com" required/>
                        </label>
                        
                        <label> Comentarios:
                            <textarea name="Comentarios" placeholder="Hasta 5 lineas..." required rows="5"></textarea>
                        </label>

                        <input type="submit" value="Enviar" class="boton"/>
                        <input type="reset" value="Limpiar" class="boton"/>

                    </form>
                </div>
            </section>
        <div>
          <Link to= "/"><button>Volver al inicio</button></Link>
        </div>

        
    
    </>
  )
}

export default Nosotros